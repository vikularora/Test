package com.shadow.books;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShadowBooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShadowBooksApplication.class, args);
	}
}
